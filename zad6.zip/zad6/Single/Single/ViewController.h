//
//  ViewController.h
//  Single
//
//  Created by student on 18/01/2024.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIButton *informationButton;
-(IBAction)enter;
@end

