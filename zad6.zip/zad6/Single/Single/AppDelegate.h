//
//  AppDelegate.h
//  Single
//
//  Created by student on 18/01/2024.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

